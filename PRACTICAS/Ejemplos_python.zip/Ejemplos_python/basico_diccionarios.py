# -*- coding: utf-8 -*-

#Declarar
diccionario = {'a': 1, 'b': 2.0}

#Añadir elemento
diccionario['c'] = False

#Eliminar elemento
del diccionario['c']

#Mostrar por pantalla
print(diccionario)

#Keys
diccionario.keys()

#Values
diccionario.values()
