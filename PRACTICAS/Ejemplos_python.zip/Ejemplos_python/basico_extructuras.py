# -*- coding: utf-8 -*-

#Condicional
if condicion:
    #Hacer algo
elif: otra_condicion:
    #Hacer algo
else:
    #Hacer algo
    
#Bucle for
for i in range(inicio, fin, paso):
    #Hacer algo

for elemento in lista:
    #Hacer algo

#Bucle while
while condicion:
    #Hacer algo
    
